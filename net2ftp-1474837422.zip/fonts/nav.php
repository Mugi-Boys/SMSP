            
            <nav class="navbar navbar-default f " role="navigation">
              <!-- El logotipo y el icono que despliega el menú se agrupan
                   para mostrarlos mejor en los dispositivos móviles -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                  <span class="sr-only">Desplegar navegación</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="media/logos.png" alt="BMN" width="120" height="60"></a>
                <div class="figLogo"></div>
              </div>
              <!-- Agrupar los enlaces de navegación, los formularios y cualquier
                   otro elemento que se pueda ocultar al minimizar la barra -->
                <div class="borde sombra"><strong>Sistema de Monitoreo de Seguridad Publica</strong></div>
              <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <li><a  href="index.html">Inicio</a></li>
                    <li><a class="nav_den" href="denuncias.php">Denuncias</a></li>
                    <li><a class="nav_est" href="estadisticas.php">Estadisticas</a></li>
                    <li><a href="info.html">Informacion</a></li>
                    <li><a class="nav_opi" href="opiniones.php">Opiniones</a></li>
                </ul>
              </div>
            </nav>