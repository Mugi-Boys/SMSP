/*-------- funcion que cuenta los caracteres de una campo de texto -------*/
function cuenta(){ 	
document.forms[0].caracteres.value=document.forms[0].situacion.value.length 
} 